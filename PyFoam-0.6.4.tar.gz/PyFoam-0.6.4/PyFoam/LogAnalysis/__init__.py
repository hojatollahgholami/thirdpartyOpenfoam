#  ICE Revision: $Id$ 
""" Log Analysis

Classes that parse the output of the OpenFOAM applications
"""
